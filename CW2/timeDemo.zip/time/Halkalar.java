package time;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import mae.util.FileList;

class Halkalar extends Clock {

    final static Color[] COL = new Color[60];
    final static Color[] BASE = { new Color(170, 20, 170), new Color(70, 70, 250),
        new Color(25, 250, 25), new Color(240, 240, 0), new Color(250, 0,  0) };
    static {
        for (int k=0, j=0; k<4; k++) 
            for (float i=0; i<15; i++) 
                COL[j++] = Colorful.interpolate(BASE[k], BASE[k+1], i/15);
    }
    
    final static String RSRC = "salihler.txt";
    final static String TITLE = "Ring of Salihin";
    final static String 
        MSG = "They believe in Allah and the Last Day, and enjoin right conduct";
    final static int H = 120, HH = 2*H;
    final static int GAP = 25;
    final static Stroke THICK = new BasicStroke(2.6f, 1, 1); 

    long msec;
    boolean turning;
    float angle;  //rotation in degrees
    Dial dial;
    final JPanel pan = new JPanel();
    final JTextArea lab = new JTextArea(MSG);
    final Ear ear = new Ear(); 

    public Halkalar() {
      try {
        dial = new Dial(MSG);
        FileList L = new FileList(getClass(), RSRC);
        for (String s: L) {
            String[] a = s.split("\t");
            int k = Integer.parseInt(a[1]);
            int j = Integer.parseInt(a[2]);
            Dot d = new Dot(a[0], k, j, a[3]);
            d.addMouseListener(ear);
            //d.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            dial.add(d);
        }
      } catch (Exception x) { //RSRC not found or corrupt
            System.out.println(x.getMessage());
            //throw new RuntimeException(x.getMessage());
      }
        pan.setLayout(new BorderLayout(GAP, GAP));
        pan.setBorder(new EmptyBorder(GAP, GAP, GAP, GAP));
        pan.setBackground(Color.lightGray);
        pan.add(dial, "Center");

        lab.setColumns(40);
        lab.setEditable(false);
        lab.setLineWrap(true);
        lab.setWrapStyleWord(true);
        lab.setBackground(Color.lightGray);
        lab.setFont(new Font("Serif", 3, 16));
        pan.add(lab, "East");
    }
    public void start() {
        startTurning(); super.start();  
    }
    public void startTurning() {
        msec = System.currentTimeMillis();
        turning = true;
        if (thread != null) thread.interrupt();
    }
    public void stopTurning() {
        setMessage(MSG);
        turning = false;
    }
    public void setAngle(float a) {
        angle = a; 
        dial.repaint();
    }
    public void setMessage(String m) {
        lab.setText(m);
    }
    public JPanel getPanel() {
        return pan;
    }
    public int doTick() {
        long t = System.currentTimeMillis() - msec;
        if (t > 120000) stopTurning(); //120 sec of inactivity
        if (turning) {
            setAngle(angle - 0.5f); //5 degrees per second COUNTER-CLOCKWISE
            return 100;  //10 times per second
        } else {
            return Integer.MAX_VALUE; //no need to check status
            //user activity interrupts sleeping thread
        }
    }

    static Dimension DD = new Dimension(7, 7);
    static Shape OVAL = new java.awt.geom.Ellipse2D.Float(1, 1, 5, 5);
    class Dot extends JComponent {
        int radius;   //distance to the center
        float theta;  //initial angle in degrees
        String msg;
        public Dot(String n, int r, float t, String m) {
            setName(n);
            setToolTipText(n);
            radius = r; theta = t; msg = m;
            setSize(DD);
            setPreferredSize(DD);
        }
        protected void paintComponent(Graphics g) {
            g.setColor(Color.black); 
            g.setClip(OVAL);
            Graphics2D G = (Graphics2D)g;
            G.fill(OVAL);
            //g.fillOval(1, 1, 5, 5); 
        }
        public void relocate() {
            double alfa = Math.PI*(theta+angle)/180;
            int x = H + (int)(radius*Math.cos(alfa) + 0.5);
            int y = H + (int)(radius*Math.sin(alfa) + 0.5);
            setLocation(x-3, y-3);
        }
    }

    class Dial extends JComponent {
        Image img; 
        public Dial(String n) {
            img = makeImage();
            setName(TITLE);
            setToolTipText("No need to click -- just move the mouse");
            setBackground(Color.lightGray);
        }
        public Dimension getPreferredSize() {
            return new Dimension(HH+1, HH+1);
        }
        Image makeImage() {
            long time = System.nanoTime();
            Image i = new java.awt.image.BufferedImage(HH, HH, 1);
            Graphics2D g = (Graphics2D)i.getGraphics();;
            g.setStroke(THICK);
            g.setColor(Color.lightGray);
            g.fillRect(0, 0, HH, HH);
            g.setColor(Color.white);
            g.fillOval(3, 3, HH-6, HH-6);
            for (int x=11; x<=H; x+=4) 
                drawRing(g, x);
            nano = System.nanoTime() - time;
            return i;
        }
        protected void paintComponent(Graphics g) {
            count++;
            long time = System.nanoTime();
            g.setColor(Color.lightGray);
            g.fillRect(0, 0, HH, HH);
            Graphics2D G = (Graphics2D)g;
            java.awt.geom.AffineTransform at = G.getTransform();
            G.translate(H, H);
            if (angle >= 180) angle = angle-360;
            double alfa = Math.PI*angle/180;
            G.rotate(alfa); //degree to radian
            G.drawImage(img, -H, -H, null);
            G.setTransform(at); //back to original state

            //float t = (val-min)/(max-min+1f);
            g.setColor(Color.black); //COL[5]);
            g.fillRect(H-5, H-5, 10, 10); //Kabe
            //g.drawString(getName(), 0, 12 /*y*/);
            //int y = fm.getHeight();
            for (Component c: getComponents()) ((Dot)c).relocate();
            nano = System.nanoTime() - time;
        }
    }
    
    class Ear extends MouseAdapter {
        public void mouseEntered(MouseEvent e) {
            startTurning();
            Dot d = (Dot)e.getSource();
            setMessage(d.getName()+"\n\n"+d.msg);
        }
        public void mouseClicked(MouseEvent e) {
            Dot d = (Dot)e.getSource();
            System.out.println("mouseClicked on "+d.getName());
        }
    }
    
    static int ringNumber(int x) {
        return Math.min(59, (x-5)/2);
    }
    static void drawRing(Graphics g, int x) {
        drawRing(g, x, COL[ringNumber(x)]);
    }
    static void drawRing(Graphics g, int x, Color c) {
        g.setColor(c);
        g.drawOval(H-x, H-x, 2*x, 2*x);
    }
    public static void main(String[] a) {
         display(new Halkalar(), TITLE, 200, 100); 
    }
}
